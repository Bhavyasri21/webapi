﻿using EmployeeManagementApi.Models;
using MobileAppApi.DTO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EmployeeManagementApi.Core.IServices
{
    public interface IRegisterServices
    {
        string AddEmployee(Registration employee);
        string signin(LoginDTO loginDTO);
    }
}
