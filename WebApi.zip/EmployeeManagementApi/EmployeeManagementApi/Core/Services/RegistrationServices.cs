﻿using EmployeeManagementApi.Core.IServices;
using EmployeeManagementApi.CustomExceptions;
using EmployeeManagementApi.Models;
using Microsoft.Exchange.WebServices.Data;
using Microsoft.Extensions.Options;
using Microsoft.IdentityModel.Tokens;
using MobileAppApi.DTO;
using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeManagementApi.Core.Services
{
    public class RegistrationServices : IRegisterServices
    {
        private readonly AppSettings _appSettings;
        EmployeeDBContext dbContext;
        public RegistrationServices(IOptions<AppSettings> appSettings,EmployeeDBContext _db)
        {
            _appSettings = appSettings.Value;
            dbContext = _db;
        }


        public string AddEmployee(Registration employee)
        {

            if (employee != null)
            {
                try
                {
                    dbContext.Registration.Add(employee);
                    dbContext.SaveChanges();
                    return "1";
                }
                catch
                {
                    try
                    {

                        throw new NoDesignationFoundException("Employee is Already Registered");
                    }
                    catch (NoDesignationFoundException e)
                    {
                        return e.Message;
                    }

                }


            }
            else
            {
                return null;
            }

        }

        public string signin(LoginDTO loginDTO)
        {
            try
            {
              

                var login = dbContext.Registration.FirstOrDefault(x => x.Empid == loginDTO.Empid && x.Password == loginDTO.Password);
                if (login != null)
                {
                    var tokenHandler = new JwtSecurityTokenHandler();
                    var key = Encoding.ASCII.GetBytes(_appSettings.Token);
                    var tokenDescriptor = new SecurityTokenDescriptor
                    {
                        Subject = new System.Security.Claims.ClaimsIdentity(new Claim[] {
                                new Claim(ClaimTypes.Name,login.Empid.ToString()),
                               // new Claim(ClaimTypes.Role,"Admin"),
                                new Claim(ClaimTypes.Version,"V3.1")

                            }),
                        Expires = DateTime.UtcNow.AddDays(2),
                        SigningCredentials = new SigningCredentials(new SymmetricSecurityKey(key), SecurityAlgorithms.HmacSha256Signature)


                    };
                    var token = tokenHandler.CreateToken(tokenDescriptor);
                    var Token = tokenHandler.WriteToken(token);
                    login.Password = null;
                    return Token;
                  

                }
                else
                {
                    return null;
                }
            }
            catch
            {
                throw;
            }
        }

        private string CreateToken(Registration user)
        {
            return string.Empty;
        }

    }
}