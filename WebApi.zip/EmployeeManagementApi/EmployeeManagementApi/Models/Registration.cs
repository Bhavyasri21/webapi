﻿using System;
using System.Collections.Generic;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace EmployeeManagementApi.Models
{
    public partial class Registration
    {
        public string Empid { get; set; }
        public string Password { get; set; }
        public string Mail { get; set; }
        //public object Email { get; internal set; }
    }
}
