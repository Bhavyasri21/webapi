﻿using EmployeeManagementApi.Core.IServices;
using EmployeeManagementApi.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EmployeeManagementApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]

    public class PaymentRulesController : Controller
    {
        private readonly IPaymentRulesServices paymentRulesServices;
        private readonly ILogger<PaymentRulesController> _logger;
        public PaymentRulesController(IPaymentRulesServices paymentRules, ILogger<PaymentRulesController> logger)
        {
            paymentRulesServices = paymentRules;
            _logger = logger;
        }


        [HttpGet("GetDetails")]

        public IActionResult GetDetails()
        {
            try
            {
                var record = paymentRulesServices.GetDetails();
                if (record == null)
                {
                    return BadRequest("No Records Found");
                }
                else
                {
                    _logger.LogInformation("records retrived");
                    return Ok(record);

                }
            }
            catch (Exception ex)
            {
                _logger.LogError("Exception Occured");
                return BadRequest(ex.Message);
            }
        }
        [HttpGet("{id}")]
        public IActionResult GetDetailsById(int id)
        {
            try
            {


                var record = paymentRulesServices.GetDetailsById(id);
                if (record == null)
                {
                    return BadRequest("Record not Found");
                }
                else
                {
                    _logger.LogInformation("records retrived");
                    return Ok(record);

                }
            }
            catch (Exception ex)
            {
                _logger.LogError("Exception Occured");
                return BadRequest(ex.Message);
            }
        }



        [HttpPost]

        public IActionResult AddPaymentRule(PaymentRules paymentRules)
        {
            try
            {
                var status = paymentRulesServices.AddPaymentRule(paymentRules);
                if (status == "1")
                {
                    _logger.LogInformation("records added");
                    return Ok(new { message = "success" });
                }
                else
                {
                    return BadRequest(status);
                }
            }
            catch (Exception ex)
            {
                _logger.LogError("Exception Occured");
                return BadRequest(ex.Message);
            }
        }

        [HttpPut("UpdatePaymentRule")]

        public IActionResult UpdatePaymentRule(PaymentRules paymentRules)
        {
            try
            {
                var status = paymentRulesServices.UpdatePaymentRule(paymentRules);
                if (status == "1")
                {
                    _logger.LogInformation("record updated");
                    return Ok(new { message = "success" });
                }
                else
                {
                    return BadRequest(status);
                }
            }
            catch (Exception ex)
            {
                _logger.LogError("Exception Occured");
                return BadRequest(ex.Message);
            }
        }

        [HttpDelete("{id}")]
        public IActionResult DeletePaymentRule(int id)
        {
            try
            {
                var status = paymentRulesServices.DeletePaymentRule(id);
                if (status == "1")
                {
                    _logger.LogInformation("record Deleted");
                    return Ok("Record Deleted Successfully");
                }
                else
                {
                    return BadRequest(status);
                }
            }
            catch (Exception ex)
            {
                _logger.LogError("Exception Occured");
                return BadRequest(ex.Message);
            }
        }

    }
}
