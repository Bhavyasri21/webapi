﻿using EmployeeManagementApi.Core.IServices;
using EmployeeManagementApi.Models;
using Microsoft.AspNetCore.Mvc;
using MobileAppApi.DTO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EmployeeManagementApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class RegistrationController : Controller
    {
        private readonly IRegisterServices registerServices;
        public RegistrationController(IRegisterServices register)
        {
            registerServices = register;
        }
        

       
        [HttpPost]

        public IActionResult AddEmployee(Registration employee)
        {
            var status = registerServices.AddEmployee(employee);
            if (status == "1")
            {
                return Ok(new { message = "success" });
            }
            else
            {
                return BadRequest(status);
            }

        }

        [HttpPost("signin")]
        public IActionResult signin(LoginDTO loginDTO)
        {
            var status1 = registerServices.signin(loginDTO);
            if (status1 == null)
            {
                return BadRequest(new { message = "Failed" });


            }
            else
            {

                return Ok(status1);
            }

        }


    }
}
