﻿using EmployeeManagementApi.Core.IServices;
using EmployeeManagementApi.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EmployeeManagementApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]

    public class WorkingHourController : Controller
    {
        private readonly IWorkingHourServices workingHourServices;
        private readonly ILogger<WorkingHourController> _logger;
        public WorkingHourController(IWorkingHourServices workingHour, ILogger<WorkingHourController> logger)
        {
            workingHourServices = workingHour;
            _logger = logger;
        }


        [HttpGet("GetWorkingHourDetails")]

        public IActionResult GetWorkingHourDetails()
        {
            try
            {
                var record = workingHourServices.GetWorkingHourDetails();
                if (record == null)
                {
                    return BadRequest("No Records Found");
                }
                else
                {
                    _logger.LogInformation("retrived");
                    return Ok(record);

                }
            }
            catch (Exception ex)
            {
                _logger.LogError("Exception Occured");
                return BadRequest(ex.Message);
            }
        }
        [HttpGet("{id}")]
        public IActionResult GetWorkingHourDetailsById(string id)
        {
            try
            {
                var record = workingHourServices.GetWorkingHourDetailsById(id);
                if (record == null)
                {
                    return BadRequest("Record not Found");
                }
                else
                {
                    _logger.LogInformation("retrived");
                    return Ok(record);

                }
            }
            catch (Exception ex)
            {
                _logger.LogError("Exception Occured");
                return BadRequest(ex.Message);
            }
        }



        [HttpPost]

        public IActionResult AddWorkingHour(WorkingHour hour)
        {
            try
            {
                var status = workingHourServices.AddWorkingHour(hour);
                if (status == "1")
                {
                    _logger.LogInformation("Added");
                    return Ok(new { message = "success" });
                }
                else
                {
                    return BadRequest(status);
                }
            }
            catch (Exception ex)
            {
                _logger.LogError("Exception Occured");
                return BadRequest(ex.Message);
            }

        }

        [HttpPut]

        public IActionResult UpdateWorkingHour(WorkingHour leave)
        {
            try
            {
                var status = workingHourServices.UpdateWorkingHour(leave);
                if (status == "1")
                {
                    _logger.LogInformation("updated");
                    return Ok(new { message = "success" });
                }
                else
                {
                    return BadRequest(status);
                }
            }
            catch (Exception ex)
            {
                _logger.LogError("Exception Occured");
                return BadRequest(ex.Message);
            }

        }

        [HttpDelete("{id}")]
        public IActionResult DeleteWorkingHour(string id)
        {
            try
            {
                var status = workingHourServices.DeleteWorkingHour(id);
                if (status == "1")
                {
                    _logger.LogInformation("deleted");
                    return Ok(new { message = "success" });
                }
                else
                {
                    return BadRequest(status);
                }
            }
            catch (Exception ex)
            {
                _logger.LogError("Exception Occured");
                return BadRequest(ex.Message);
            }
        }
    }
}
