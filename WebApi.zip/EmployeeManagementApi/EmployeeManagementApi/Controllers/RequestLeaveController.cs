﻿using EmployeeManagementApi.Core.IServices;
using EmployeeManagementApi.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EmployeeManagementApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class RequestLeaveController : Controller
    {
        private readonly IRequestLeaveServices requestLeaveServices;
        private readonly ILogger<RequestLeaveController> _logger;
        public RequestLeaveController(IRequestLeaveServices requestLeave, ILogger<RequestLeaveController> logger)
        {
            requestLeaveServices = requestLeave;
            _logger = logger;
        }


        [HttpGet("GetLeaveDetails")]

        public IActionResult GetLeaveDetails()
        {
            try
            {
                var record = requestLeaveServices.GetLeaveDetails();
                if (record == null)
                {
                    return BadRequest("No Records Found");
                }
                else
                {
                    _logger.LogInformation("retrived");
                    return Ok(record);

                }
            }
            catch (Exception ex)
            {
                _logger.LogError("Exception Occured");
                return BadRequest(ex.Message);
            }

        }
        [HttpGet("{id}")]
        public IActionResult GetLeaveDetailsById(string id)
        {
            try
            {
                var record = requestLeaveServices.GetLeaveDetailsById(id);
                if (record == null)
                {
                    return BadRequest("Record not Found");
                }
                else
                {
                    _logger.LogInformation("retrived");
                    return Ok(record);

                }
            }
            catch (Exception ex)
            {
                _logger.LogError("Exception Occured");
                return BadRequest(ex.Message);
            }

        }



        [HttpPost]

        public IActionResult AddLeave(RequestLeave leave)
        {
            try
            {
                var status = requestLeaveServices.AddLeave(leave);
                if (status == "1")
                {
                    _logger.LogInformation("Added");
                    return Ok(new { message = "success" });
                }
                else
                {
                    return BadRequest(status);
                }
            }
            catch (Exception ex)
            {
                _logger.LogError("Exception Occured");
                return BadRequest(ex.Message);
            }

        }

        [HttpPut("UpdateLeave")]

        public IActionResult UpdateLeave(RequestLeave leave)
        {
            try
            {
                var status = requestLeaveServices.UpdateLeave(leave);
                if (status == "1")
                {
                    _logger.LogInformation("updated");
                    return Ok(new { message = "success" });
                }
                else
                {
                    return BadRequest(status);
                }
            }
            catch (Exception ex)
            {
                _logger.LogError("Exception Occured");
                return BadRequest(ex.Message);
            }
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteLeave(string id)
        {
            try
            {
                var status = requestLeaveServices.DeleteLeave(id);
                if (status == "1")
                {
                    _logger.LogInformation("deleted");
                    return Ok("Record Deleted Successfully");
                }
                else
                {
                    return BadRequest(status);
                }
            }
            catch (Exception ex)
            {
                _logger.LogError("Exception Occured");
                return BadRequest(ex.Message);
            }
        }
    }
}
