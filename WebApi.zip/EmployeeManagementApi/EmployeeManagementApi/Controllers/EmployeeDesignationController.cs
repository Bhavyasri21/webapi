﻿using EmployeeManagementApi.Core.IServices;
using EmployeeManagementApi.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EmployeeManagementApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]

    public class EmployeeDesignationController : Controller
    {
        private readonly IEmployeeDesignationServices employeeDesignationServices;
        private readonly ILogger<EmployeeDesignationController> _logger;
        public EmployeeDesignationController(IEmployeeDesignationServices employee, ILogger<EmployeeDesignationController> logger)
        {
            employeeDesignationServices = employee;
            _logger = logger;
        }


        [HttpGet("GetDetails")]

        public IActionResult GetDetails()
        {
            try
            {


                var record = employeeDesignationServices.GetDetails();
                if (record != null)
                {
                    _logger.LogInformation("records retrived");
                    return Ok(record);

                }
                else
                {
                   
                    return BadRequest("No Records Found");


                }
            }
            catch(Exception ex)
            {
                _logger.LogError("Exception Occured");
                return BadRequest(ex.Message);
            }
          
        }
        [HttpGet("{designation}")]
        public IActionResult GetDetailsByDesignation(string designation)
        {
            try
            {
                var record = employeeDesignationServices.GetDetailsByDesignation(designation);
                if (record != null)
                {
                    _logger.LogInformation("records retrived");
                    return Ok(record);


                }
                else
                {
                    return BadRequest("Record not Found");

                }
            }
            catch(Exception ex)
            {
                _logger.LogError("Exception Occured");
                return BadRequest(ex.Message);
            }
   
        }



        [HttpPost]
       
        public IActionResult AddDesignation(EmployeeDesignation employeeDesignation)
        {
            try
            {
                var status = employeeDesignationServices.AddDesignation(employeeDesignation);
                if (status == "1")
                {
                    _logger.LogInformation("records Added");
                    return Ok(new { message = "success" });
                }
                else
                {
                    return BadRequest(status);
                }
            }
            catch(Exception ex)
            {
                _logger.LogError("Exception Occured");
                return BadRequest(ex.Message);
            }
  
        }
       
        [HttpPut("UpdateDesignation")]
       
        public IActionResult UpdateDesignation(EmployeeDesignation employeeDesignation)
        {
            try
            {
                var status = employeeDesignationServices.UpdateDesignation(employeeDesignation);
                if (status == "1")
                {
                    _logger.LogInformation("records updated");
                    return Ok(new { message = "success" });
                }
                else
                {
                    return BadRequest(status);
                }
            }
            catch(Exception ex)
            {
                _logger.LogError("Exception Occured");
                return BadRequest(ex.Message);
            }

    
        }

        [HttpDelete("{designation}")]
        public IActionResult DeleteDesignation(string designation)
        {
            try
            {
                var status = employeeDesignationServices.DeleteDesignation(designation);
                if (status == "1")
                {
                    _logger.LogInformation("records deleted");
                    return Ok("Record Deleted Successfully");
                }
                else
                {
                    return BadRequest(status);
                }
            }
            catch
            {
                _logger.LogWarning("Exception Occured");
                throw;
            }
   
        }

    }
}
