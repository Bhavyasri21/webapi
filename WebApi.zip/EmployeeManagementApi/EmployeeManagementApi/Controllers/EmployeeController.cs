﻿using EmployeeManagementApi.Core.IServices;
using EmployeeManagementApi.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using MobileAppApi.DTO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EmployeeManagementApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]

    public class EmployeeController : Controller
    {
        private readonly IEmployeeServices employeeServices;
        private readonly ILogger<EmployeeController> _logger;
        public EmployeeController(IEmployeeServices employee, ILogger<EmployeeController> logger)
        {
            employeeServices = employee;
            _logger = logger;
        }
       

        


        [HttpGet("GetDetails")]

        public IActionResult GetDetails()
        {
            try
            {
                var record = employeeServices.GetDetails();
                if (record != null)
                {
                    
                    return Ok(record);
                    _logger.LogInformation("retrived");
                    
                }
                else
                {
                    _logger.LogWarning("no record Found");
                    return BadRequest("No Records Found");

                }
            }
            catch(Exception ex)
            {
                _logger.LogError("Exception Occured");
                return BadRequest(ex.Message);
            }


        }
        [HttpGet("{id}")]
        public IActionResult GetDetailsById(string id)
        {
            try
            {
                if(id!=null)
                {
                    var record = employeeServices.GetDetailsById(id);
                    if (record != null)
                    {
                        _logger.LogInformation("Processing To Retrived Details");
                        return Ok(record);
                        
                    }
                    else
                    {
                        _logger.LogWarning("record not found");
                        return BadRequest("Record not Found");

                    }
                }
                else
                {
                    _logger.LogError("Enter Valid Id");
                    return BadRequest("Please Enter Valid ID");
                }
                
            }
            catch(Exception ex)
            {
                _logger.LogError("Exception Occured");
                return BadRequest(ex.Message);
            }

        }



        [HttpPost("AddEmployee")]

        public IActionResult AddEmployee(Employee employee)
        {
            try
            {
                var status = employeeServices.AddEmployee(employee);
                if (status == "1")
                {
                    _logger.LogInformation("Record Added Successfully");
                    return Ok(new { message = "success" });
                }
                else
                {
                    _logger.LogWarning("Error Occured");
                    return BadRequest(status);
                }
            }
            catch(Exception ex)
            {
                _logger.LogError("Exception Occured");
                return BadRequest(ex.Message);

            }

        }

        [HttpPut("UpdateEmployee")]

        public IActionResult UpdateEmployee(Employee employee)
        {
            try
            {
                var status = employeeServices.UpdateEmployee(employee);
                if (status == "1")
                {
                    _logger.LogInformation("Record updated Successfully");
                    return Ok(new { message = "success" });
                }
                else
                {
                    _logger.LogWarning("Error Occured");
                    return BadRequest(status);
                }
            }
            catch(Exception ex)
            {
                _logger.LogError("Exception Occured");
                return BadRequest(ex.Message);
            }

        }

        [HttpDelete("{id}")]
        public IActionResult DeleteEmployee(string id)
        {
            try
            {
                if (id != null)
                {
                    var status = employeeServices.DeleteEmployee(id);
                    if (status == "1")
                    {
                        _logger.LogInformation("Delete Sucessfully");
                        return Ok("Record Deleted Successfully");
                    }
                    else
                    {
                        _logger.LogWarning("Error Occured");
                        return BadRequest(status);
                    }
                }
                else
                {
                    _logger.LogError("enter Id");
                    return BadRequest("Please Enter Valid ID");

                }
            }
                   
            catch(Exception ex)
            {
                _logger.LogError("Exception Occured");
                return BadRequest(ex.Message);
            }
        }



        



    }
}
