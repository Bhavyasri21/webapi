﻿using EmployeeManagementApi.Controllers;
using EmployeeManagementApi.Core.IServices;
using EmployeeManagementApi.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using Ploeh.AutoFixture;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConversionTest
{
    [TestClass]
    public class WorkingHourTests
    {
        private IWorkingHourServices _workingHourServices;
        private Fixture _fixture;
        private WorkingHourController _controller;
        private List<WorkingHour> g;
        public WorkingHourTests()
        {
            _fixture = new Fixture();
            var mockBar = new Mock<IWorkingHourServices>();
            g = new List<WorkingHour>();
            WorkingHour a = new WorkingHour { Sno = 2, MonthYear = "abc", CompanyWorkingHours = "665", EmployeeWorkingHours = "45", Employeeshift="day",Empid = "m101" };
            g.Add(a);
            IEnumerable<WorkingHour> hh = g.AsEnumerable();
        }
        [TestMethod]
        public async Task Get_WorkingHourReturnOK()
        {
            var mockBar = new Mock<IWorkingHourServices>();
            mockBar.Setup(mock => mock.GetWorkingHourDetails()).Returns(g);
            _workingHourServices = new Mock<IWorkingHourServices>().Object;
            var record = _workingHourServices.GetWorkingHourDetails();
            Assert.IsNotNull(record);
        }
        [TestMethod]
        public async Task Get_WorkingHour_givecorrectresulttypeIncaseWorkingHour()
        {

            var mockBar = new Mock<IWorkingHourServices>();
            mockBar.Setup(mock => mock.GetWorkingHourDetails()).Returns(g.AsEnumerable());


            var mock1 = new Mock<ILogger<WorkingHourController>>();
            ILogger<WorkingHourController> Loginmock = mock1.Object;

            //Arrage
            WorkingHourController subject = new WorkingHourController(mockBar.Object, Loginmock);

            //Act
            IActionResult result = subject.GetWorkingHourDetails();
            var contentResult = result as OkObjectResult;

            //Assert

            Assert.IsNotNull(contentResult);



        }
        [TestMethod]
        public async Task Get_WorkingHour_givecorrectresulttypeIncaseNoWorkingHour()
        {
            IEnumerable<WorkingHour> dummydata = null;

            var mockBar2 = new Mock<IWorkingHourServices>();
            mockBar2.Setup(mock => mock.GetWorkingHourDetails()).Returns(dummydata);


            var mock1 = new Mock<ILogger<WorkingHourController>>();
            ILogger<WorkingHourController> Loginmock = mock1.Object;

            //Arrage
            WorkingHourController subject = new WorkingHourController(mockBar2.Object, Loginmock);

            //Act
            IActionResult result = subject.GetWorkingHourDetails();
            var contentResult = result as BadRequestObjectResult;

            //Assert

            Assert.IsNotNull(contentResult);



        }
    }
}
