﻿using EmployeeManagementApi.Controllers;
using EmployeeManagementApi.Core.IServices;
using EmployeeManagementApi.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using Ploeh.AutoFixture;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConversionTest
{
    [TestClass]
    public class PaymentRulesTests
    {
        private IPaymentRulesServices _paymentRulesServices;
        private Fixture _fixture;
        private PaymentRulesController _controller;
        private List<PaymentRules> g;
        public PaymentRulesTests()
        {
            _fixture = new Fixture();
            var mockBar = new Mock<IPaymentRulesServices>();
            g = new List<PaymentRules>();
            PaymentRules a = new PaymentRules { Id = 2,Category = "abc", RuleDescription="xyz"};
            g.Add(a);
            IEnumerable<PaymentRules> hh = g.AsEnumerable();
        }
       
        [TestMethod]
        public async Task Get_PaymentRules_ReturnOK()
        {
            var mockBar = new Mock<IPaymentRulesServices>();
            mockBar.Setup(mock => mock.GetDetails()).Returns(g);
            _paymentRulesServices = new Mock<IPaymentRulesServices>().Object;
            var record = _paymentRulesServices.GetDetails();
            Assert.IsNotNull(record);
        }
        [TestMethod]
        public async Task Get_PaymentRules_givecorrectresulttypeIncasePaymentRules()
        {

            var mockBar = new Mock<IPaymentRulesServices>();
            mockBar.Setup(mock => mock.GetDetails()).Returns(g.AsEnumerable());


            var mock1 = new Mock<ILogger<PaymentRulesController>>();
            ILogger<PaymentRulesController> Loginmock = mock1.Object;

            //Arrage
            PaymentRulesController subject = new PaymentRulesController(mockBar.Object, Loginmock);

            //Act
            IActionResult result = subject.GetDetails();
            var contentResult = result as OkObjectResult;

            //Assert

            Assert.IsNotNull(contentResult);



        }
        [TestMethod]
        public async Task Get_PaymentRules_givecorrectresulttypeIncaseNoPaymentRules()
        {
            IEnumerable<PaymentRules> dummydata = null;

            var mockBar2 = new Mock<IPaymentRulesServices>();
            mockBar2.Setup(mock => mock.GetDetails()).Returns(dummydata);


            var mock1 = new Mock<ILogger<PaymentRulesController>>();
            ILogger<PaymentRulesController> Loginmock = mock1.Object;

            //Arrage
            PaymentRulesController subject = new PaymentRulesController(mockBar2.Object, Loginmock);

            //Act
            IActionResult result = subject.GetDetails();
            var contentResult = result as BadRequestObjectResult;

            //Assert

            Assert.IsNotNull(contentResult);



        }


    }
}
