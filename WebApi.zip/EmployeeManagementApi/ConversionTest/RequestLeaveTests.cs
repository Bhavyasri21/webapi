﻿using EmployeeManagementApi.Controllers;
using EmployeeManagementApi.Core.IServices;
using EmployeeManagementApi.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using Ploeh.AutoFixture;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConversionTest
{
    [TestClass]
    public class RequestLeaveTests
    {
        private IRequestLeaveServices _requestLeaveServices;
        private Fixture _fixture;
        private RequestLeaveController _controller;
        private List<RequestLeave> g;
        public RequestLeaveTests()
        {
            _fixture = new Fixture();
            var mockBar = new Mock<IRequestLeaveServices>();
            g = new List<RequestLeave>();
            RequestLeave a = new RequestLeave { Sno = 2, RequestType = "abc", NoOfDays=2, LeaveReason="xfcgvhb", Empid="m101"};
            g.Add(a);
            IEnumerable<RequestLeave> hh = g.AsEnumerable();
        }
        [TestMethod]
        public async Task Get_RequestLeave_ReturnOK()
        {
            var mockBar = new Mock<IRequestLeaveServices>();
            mockBar.Setup(mock => mock.GetLeaveDetails()).Returns(g);
            _requestLeaveServices = new Mock<IRequestLeaveServices>().Object;
            var record = _requestLeaveServices.GetLeaveDetails();
            Assert.IsNotNull(record);
        }
        [TestMethod]
        public async Task Get_RequestLeave_givecorrectresulttypeIncaseRequestLeave()
        {

            var mockBar = new Mock<IRequestLeaveServices>();
            mockBar.Setup(mock => mock.GetLeaveDetails()).Returns(g.AsEnumerable());


            var mock1 = new Mock<ILogger<RequestLeaveController>>();
            ILogger<RequestLeaveController> Loginmock = mock1.Object;

            //Arrage
            RequestLeaveController subject = new RequestLeaveController(mockBar.Object, Loginmock);

            //Act
            IActionResult result = subject.GetLeaveDetails();
            var contentResult = result as OkObjectResult;

            //Assert

            Assert.IsNotNull(contentResult);



        }
        [TestMethod]
        public async Task Get_RequestLeave_givecorrectresulttypeIncaseNoRequestLeave()
        {
            IEnumerable<RequestLeave> dummydata = null;

            var mockBar2 = new Mock<IRequestLeaveServices>();
            mockBar2.Setup(mock => mock.GetLeaveDetails()).Returns(dummydata);


            var mock1 = new Mock<ILogger<RequestLeaveController>>();
            ILogger<RequestLeaveController> Loginmock = mock1.Object;

            //Arrage
            RequestLeaveController subject = new RequestLeaveController(mockBar2.Object, Loginmock);

            //Act
            IActionResult result = subject.GetLeaveDetails();
            var contentResult = result as BadRequestObjectResult;

            //Assert

            Assert.IsNotNull(contentResult);



        }


    }
}
