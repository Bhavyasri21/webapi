﻿using EmployeeManagementApi.Controllers;
using EmployeeManagementApi.Core.IServices;
using EmployeeManagementApi.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using Ploeh.AutoFixture;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConversionTest
{
    [TestClass]
    public class DesignationControllerTests
    {
        private IEmployeeDesignationServices _employeeDesignationServices;
        private Fixture _fixture;
        private EmployeeDesignationController _controller;
        private List<EmployeeDesignation> g;

        public DesignationControllerTests()
        {
            _fixture = new Fixture();
            var mockBar = new Mock<IEmployeeDesignationServices>();
            g = new List<EmployeeDesignation>();
            EmployeeDesignation a = new EmployeeDesignation {Designation = "tester", Role="abc",Department="xyz"};
            g.Add(a);
            IEnumerable<EmployeeDesignation> hh = g.AsEnumerable();
        }
        [TestMethod]
        public async Task Get_Designation_Details()
        {
            var mockBar = new Mock<IEmployeeDesignationServices>();
            mockBar.Setup(mock => mock.GetDetails()).Returns(g);
            _employeeDesignationServices = new Mock<IEmployeeDesignationServices>().Object;
            var record = _employeeDesignationServices.GetDetails();
            Assert.IsNotNull(record);
        }
       
        [TestMethod]
        public async Task Get_EmployeeDesignation_givecorrectresulttypeIncaseDesignation()
        {

            var mockBar = new Mock<IEmployeeDesignationServices>();
            mockBar.Setup(mock => mock.GetDetails()).Returns(g.AsEnumerable());


            var mock1 = new Mock<ILogger<EmployeeDesignationController>>();
            ILogger<EmployeeDesignationController> Loginmock = mock1.Object;

            //Arrage
            EmployeeDesignationController subject = new EmployeeDesignationController(mockBar.Object, Loginmock);

            //Act
            IActionResult result = subject.GetDetails();
            var contentResult = result as OkObjectResult;

            //Assert

            Assert.IsNotNull(contentResult);



        }
        [TestMethod]
        public async Task Get_Employee_givecorrectresulttypeIncaseNoDesignation()
        {
            IEnumerable<EmployeeDesignation> dummydata = null;

            var mockBar2 = new Mock<IEmployeeDesignationServices>();
            mockBar2.Setup(mock => mock.GetDetails()).Returns(dummydata);


            var mock1 = new Mock<ILogger<EmployeeDesignationController>>();
            ILogger<EmployeeDesignationController> Loginmock = mock1.Object;

            //Arrage
            EmployeeDesignationController subject = new EmployeeDesignationController(mockBar2.Object, Loginmock);

            //Act
            IActionResult result = subject.GetDetails();
            var contentResult = result as BadRequestObjectResult;

            //Assert

            Assert.IsNotNull(contentResult);



        }

    }
}
