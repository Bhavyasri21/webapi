﻿using EmployeeManagementApi.Controllers;
using EmployeeManagementApi.Core.IServices;
using EmployeeManagementApi.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using Ploeh.AutoFixture;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.Http.Results;

namespace ConversionTest
{
    [TestClass]
   public class EmployeeControllerTests
    {
        private IEmployeeServices _employeeServices;
        private Fixture _fixture;
        private EmployeeController _controller;
        private List<Employee> g;
        public EmployeeControllerTests()
        {
            _fixture = new Fixture();
            var mockBar = new Mock<IEmployeeServices>();
            g = new List<Employee>();
            Employee a = new Employee { Empid = "2", Empname = "bhavya", Phone = "6545", Address = "dfgh", DesignationName = "xdfcghj", Mail = "xdfcgvh" };
            g.Add(a);
            IEnumerable<Employee> hh = g.AsEnumerable();
        }
        [TestMethod]
        public async Task Get_Employee_ReturnOK()
        {
            var mockBar = new Mock<IEmployeeServices>();
            mockBar.Setup(mock => mock.GetDetails()).Returns(g);
            _employeeServices = new Mock<IEmployeeServices>().Object;
            var record = _employeeServices.GetDetails();
            Assert.IsNotNull(record);
        }
        [TestMethod]
        public async Task Get_Employee_givecorrectresulttypeIncaseEmployee()
        {

            var mockBar = new Mock<IEmployeeServices>();
            mockBar.Setup(mock => mock.GetDetails()).Returns(g.AsEnumerable());


            var mock1 = new Mock<ILogger<EmployeeController>>();
            ILogger<EmployeeController> Loginmock = mock1.Object;

            //Arrage
            EmployeeController subject = new EmployeeController(mockBar.Object,Loginmock);

            //Act
            IActionResult result = subject.GetDetails();
            var contentResult = result as OkObjectResult;

            //Assert

            Assert.IsNotNull(contentResult);



        }
        [TestMethod]
        public async Task Get_Employee_givecorrectresulttypeIncaseNoEmployee()
        {
            IEnumerable<Employee> dummydata = null;

            var mockBar2 = new Mock<IEmployeeServices>();
            mockBar2.Setup(mock => mock.GetDetails()).Returns(dummydata);


            var mock1 = new Mock<ILogger<EmployeeController>>();
            ILogger<EmployeeController> Loginmock = mock1.Object;

            //Arrage
            EmployeeController subject = new EmployeeController(mockBar2.Object,Loginmock);

            //Act
            IActionResult result = subject.GetDetails();
            var contentResult = result as BadRequestObjectResult;

            //Assert

            Assert.IsNotNull(contentResult);



        }
       

    }
 }
